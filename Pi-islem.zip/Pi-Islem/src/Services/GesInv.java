/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import utiles.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import models.Invitation;
/**
 *
 * @author Islem
 */
public class GesInv implements IServices <Invitation>{
 java.sql.Connection cnx = Connection.getInstance().getCnx();
    @Override
    public void ajouter(Invitation i) {
        try {
            String requete = "INSERT INTO invitation (id_invitation,nom_user,nom_event) VALUES (?,?,?)";
            PreparedStatement pst3 = cnx.prepareStatement(requete);
            pst3.setInt(1, i.getId());
            pst3.setString(2, i.getNom_user());
            pst3.setString(3, i.getNom_event());
            pst3.executeUpdate();
            System.out.println("invitation envoyé !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public void supprimer(Invitation i) {
        try {
         String requete = "DELETE FROM invitation WHERE nom_user=? and nom_event=?";//
            PreparedStatement pst = cnx.prepareStatement(requete);
          pst.setString(1, i.getNom_user());
            pst.setString(2, i.getNom_event());
            pst.executeUpdate();
            System.out.println("invitation supprimée avec succés  ! \n");
        } 
catch (SQLException ex) {
            System.out.println("erreur lors de la suppression \n" + ex.getMessage());
        }
    }

    @Override
    public void modifier(Invitation t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Invitation> afficher() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
