/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import Services.Activite;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;
import models.Act;
/**
 * FXML Controller class
 *
 * @author Islem
 */
public class ActController implements Initializable {


    @FXML
    private Button Ajout;
    @FXML
    private TextField idcol;
    @FXML
    private TextField nomcol;
    @FXML
    private TextField typecol;
     @FXML
    private Button Aff;

    @FXML
    private TableView<Act> tabid;

    @FXML
    private TableColumn<Act, Integer> id1;

    @FXML
    private TableColumn<Act, String> nom1;

    @FXML
    private TableColumn<Act, String> type1;
private ObservableList<Act> activs = FXCollections.observableArrayList();
  
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void Ajout(ActionEvent event) {
        Activite ac =new Activite();
        int x = Integer.parseInt(idcol.getText());
        ac.ajouter(new Act (x,nomcol.getText(),typecol.getText()));
        JOptionPane.showMessageDialog(null,"act ajouté");
    }
  @FXML
    void Affiche(ActionEvent event) {
Act c=new Act(4,"aa","cc");
      activs.add(c);
     
     id1.setCellValueFactory(new PropertyValueFactory<Act,Integer>("id_act"));
     nom1.setCellValueFactory(new PropertyValueFactory<Act,String>("nom_act"));        
     type1.setCellValueFactory(new PropertyValueFactory<Act,String>("type_act"));
         try {
             Activite t = new Activite();
      
      for(Act acct : t.afficher()){
      activs.add(new Act( acct.getId_act(), acct.getNom_act(), acct.getType_act()));     }
        
       tabid.setItems(activs); 
     
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
    }
}
}