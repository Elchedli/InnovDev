/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import Services.GererEv;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import static com.itextpdf.text.pdf.PdfFileSpecification.url;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.jfoenix.controls.JFXTimePicker;
import java.awt.Desktop;
import java.awt.HeadlessException;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;
import models.Ev;
import static org.omg.CORBA.AnySeqHelper.type;
import utiles.Connection;
import java.sql.PreparedStatement;
import java.time.Duration;
import java.time.LocalTime;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import org.controlsfx.control.Notifications;

/**
 * FXML Controller class
 *
 * @author Islem
 */
public class EvenementController implements Initializable {

    @FXML
    private TableView<Ev> tabid;
    @FXML
    private TableColumn<Ev, String> colnom;
    @FXML
    private TableColumn<Ev, String> coltype;
    @FXML
    private TableColumn<Ev, String> colemplacement;
    @FXML
    private TableColumn<Ev, Date> colDate_deb;
    @FXML
    private TableColumn<Ev, Date> colDate_fin;
    @FXML
    private TableColumn<Ev,Time> colTemps_deb;
    @FXML
    private TableColumn<Ev,Time> colTemps_fin;
    @FXML
    private TableColumn<Ev, Integer> colAge_min;
    @FXML
    private TableColumn<Ev, Integer> colAge_max;
      @FXML
    private Button pdf;

    @FXML
    private TextField age_max;
    @FXML
    private TextField titre;
    @FXML
    private TextField emplacement;
    @FXML
    private JFXTimePicker temps_deb;
      @FXML
    private JFXTimePicker  temps_deb2;
    @FXML
    private DatePicker date_deb1;
    @FXML
    private DatePicker date_fin1;
    @FXML
    private TextField age_min;
 
    @FXML
    private Button ajout;
    @FXML
    private ComboBox<String> type;

    @FXML
    private Button supprimer;

    @FXML
    private Button modifier;

    @FXML
    private TextField titre_ev;

    @FXML
    private TextField age_max1;

    @FXML
    private TextField age_min1;

    @FXML
    private TextField temps_fin1;

    @FXML
    private TextField temps_deb1;

    @FXML
    private TextField emplacement1;

    @FXML
    private TextField titre_ev141;

    @FXML
    private TextField id;

    @FXML
    private ComboBox<String> type1;

    @FXML
    private DatePicker date_deb11;

    @FXML
    private DatePicker date_fin11;
    @FXML
    private Button afficher;
    
 private ObservableList<Ev> activs = FXCollections.observableArrayList();
 java.sql.Connection cnx = Connection.getInstance().getCnx();
 String requete = "SELECT titre_ev ,type_ev,emplacement_ev FROM evenement";

    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      ObservableList<String> event = FXCollections.observableArrayList("sportif","educatif","loisir");
        type.setItems(event);
        String s = type.getSelectionModel().getSelectedItem();
       ObservableList<String> events = FXCollections.observableArrayList("sportif","educatif","loisir");
        type1.setItems(event);
        String s1 = type1.getSelectionModel().getSelectedItem();
    }    

    @FXML
    private void ajouter(ActionEvent event) {
   
    GererEv e=new GererEv();
    
   if (titre.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Veuillez remplir tous les champs");
            alert.showAndWait(); }
   else 
   {Ev test = new Ev(titre.getText(),type.getValue(),emplacement.getText(),Date.valueOf(date_deb1.getValue()),Date.valueOf(date_fin1.getValue()),Time.valueOf(temps_deb.getValue()),Time.valueOf(temps_deb2.getValue()),Integer.parseInt(age_min.getText()),Integer.parseInt(age_min.getText()));
       e.ajouter(test);
    JOptionPane.showMessageDialog(null,"event ajouté");}
    }

//    Notifications notificationBuilder = Notifications.create()
//              .title("Demande D'ajout")
//                    .text("Merci pour attendre la réponse")
//                    .graphic(new ImageView())
//                    .hideAfter(javafx.util.Duration.seconds(5))
//                    .position(Pos.TOP_CENTER);
//
//            notificationBuilder.show(); }
//			
//       if ( titre.getText().matches(".*[0-9].*")||titre.getText().matches(".*[%-@-_].*")) {
//            Alert a2 = new Alert(Alert.AlertType.ERROR);
//            a2.setHeaderText(null);
//            a2.setContentText("Veuillez saisir uniquement des lettres ! ");
//            a2.showAndWait();
//}
    
       
       @FXML
    void modifier(ActionEvent event) {
        
  GererEv e=new GererEv();
    Ev test = new Ev( Integer.parseInt(id.getText()) ,titre_ev141.getText(),type1.getValue(),emplacement1.getText(),Date.valueOf(date_deb11.getValue()),Date.valueOf(date_fin11.getValue()),temps_deb1.getText(),temps_fin1.getText(),Integer.parseInt(age_min1.getText()),Integer.parseInt(age_max1.getText()));
    e.modifier(test);
    JOptionPane.showMessageDialog(null,"event modifié");
    }

    @FXML
    void supprimer(ActionEvent event) {
     GererEv e=new GererEv();
    Ev test = new Ev(titre_ev.getText());
    e.supprimer(test);
    //JOptionPane.showMessageDialog(null,"event supprimé");

    }
    

    @FXML
    void afficher() throws SQLException, DocumentException, BadElementException, IOException {
        colnom.setCellValueFactory(new PropertyValueFactory<Ev,String>("titre_ev"));     
        coltype.setCellValueFactory(new PropertyValueFactory<Ev,String>("type_ev"));        
        colemplacement.setCellValueFactory(new PropertyValueFactory<Ev,String>("emplacement_ev"));        
        colDate_deb.setCellValueFactory(new PropertyValueFactory<Ev,Date>("Date_dev"));   
        colDate_fin.setCellValueFactory(new PropertyValueFactory<Ev,Date>("Date_fev")); 
        colTemps_deb.setCellValueFactory(new PropertyValueFactory<Ev,Time>("temps_dev"));
        colTemps_fin.setCellValueFactory(new PropertyValueFactory<Ev,Time>("temps_fev")); 


        colAge_min.setCellValueFactory(new PropertyValueFactory<Ev,Integer>("Age_min"));        
        colAge_max.setCellValueFactory(new PropertyValueFactory<Ev,Integer>("Age_max"));        
        GererEv t = new GererEv();
        t.afficher().forEach(e->activs.add(e));
        tabid.setItems(activs);
    }
      public boolean controleTextFieldVide(TextField textField, String msg, Label errorLabel) {
        String chaine = textField.getText().trim();
        if (chaine.length() == 0) {
            errorLabel.setText(msg);
            textField.clear();
            return true;
        }
        return false;
    }

    @FXML
 private void CreatePDF(ActionEvent event) throws SQLException, IOException, DocumentException {
    
     try {
       Document doc = new Document();
       PdfWriter.getInstance(doc,new FileOutputStream("C:\\Users\\Islem\\Desktop\\Pi\\src\\pdf\\Evenement.pdf"));
       doc.open();
       
      Image img = Image.getInstance("C:\\Users\\Islem\\Desktop\\Pi\\src\\img\\img.jpg");
       img.scaleAbsoluteHeight(60);
       img.scaleAbsoluteWidth(100);
       img.setAlignment(Image.ALIGN_RIGHT);
       doc.open();
       doc.add(img);
    
       doc.add(new Paragraph(" "));
       Font font = new Font(FontFamily.TIMES_ROMAN, 28, Font.UNDERLINE, BaseColor.BLACK);
       Paragraph p = new Paragraph("List of Event for Spirity", font);
       p.setAlignment(Element.ALIGN_CENTER);
       doc.add(p);
       doc.add(new Paragraph(" "));
       doc.add(new Paragraph(" "));
 

       PdfPTable tabpdf = new PdfPTable(3);
       tabpdf.setWidthPercentage(100);
       
       PdfPCell cell;
       cell = new PdfPCell(new Phrase("nom", FontFactory.getFont("Times New Roman", 11)));
       cell.setHorizontalAlignment(Element.ALIGN_CENTER);
       cell.setBackgroundColor(BaseColor.WHITE);
       tabpdf.addCell(cell);
       
       cell = new PdfPCell(new Phrase("type", FontFactory.getFont("Times New Roman", 11)));
       cell.setHorizontalAlignment(Element.ALIGN_CENTER);
       cell.setBackgroundColor(BaseColor.WHITE);
       tabpdf.addCell(cell);
       
       cell = new PdfPCell(new Phrase("emplacement", FontFactory.getFont("Times New Roman", 11)));
       cell.setHorizontalAlignment(Element.ALIGN_CENTER);
       cell.setBackgroundColor(BaseColor.WHITE);
       tabpdf.addCell(cell);
      
       PreparedStatement pst = cnx.prepareStatement(requete);
       ResultSet rs = pst.executeQuery();
       while (rs.next()) {
           cell = new PdfPCell(new Phrase("titre_ev", FontFactory.getFont("Times New Roman", 11)));
           cell.setHorizontalAlignment(Element.ALIGN_CENTER);
           cell.setBackgroundColor(BaseColor.WHITE);
           tabpdf.addCell(cell);
           System.out.println("ok");
           cell = new PdfPCell(new Phrase(rs.getString("type_ev"), FontFactory.getFont("Times New Roman", 11)));
           cell.setHorizontalAlignment(Element.ALIGN_CENTER);
           cell.setBackgroundColor(BaseColor.WHITE);
           tabpdf.addCell(cell);
           
           cell = new PdfPCell(new Phrase(rs.getString("emplacement_ev"), FontFactory.getFont("Times New Roman", 11)));
           cell.setHorizontalAlignment(Element.ALIGN_CENTER);
           cell.setBackgroundColor(BaseColor.WHITE);
           tabpdf.addCell(cell);
       }
          doc.add(tabpdf);
          JOptionPane.showMessageDialog(null, "Success !!");
          doc.close();
          Desktop.getDesktop().open(new File("C:\\Users\\Islem\\Desktop\\Pi\\src\\pdf\\Evenement.pdf"));
       }
 
        catch (DocumentException | HeadlessException | IOException e) {
            System.out.println("ERROR PDF");
            System.out.println(Arrays.toString(e.getStackTrace()));
            System.out.println(e.getMessage());
          }
    
 }
}
     
   