/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;
import models.Ev;
import Services.IServices;
import Services.GererEv;
import Services.GesInv;
import Services.Activite;
import models.Act;
import models.Invitation;

import utiles.Connection;

/**
 *
 * @author Islem
 */
public class PiTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Connection c = Connection.getInstance();
     GererEv e = new GererEv();
     //e.afficher().forEach(System.out::println);//
    /* e.ajouter(new Ev ("HELLO","ppp","YYY", "2021-02-08","2021-02-10","08:30:20","20:30:20", 10,20));
      e.ajouter(new Ev ("test","wow","okk", "1999-01-08","1963-06-07","10:00:23","12:25:02", 4,9)); 
     e.modifier (new Ev (7,"bnjour","la","vie", "1789-08-08","1569-02-02","12:00:15","12:18:00", 8,10));
     e.afficher().forEach(System.out::println);
     e.supprimer (new Ev ("bnjour"));
         
     
    e.supprimer(new Ev ("ok","","","","","","",0,0));
    e.triNom().forEach(System.out::println);
     e.RechercheNom("islem").forEach(System.out::println);*/
    // e.afficherEventparActivite("chant").forEach(System.out::println);
    
    System.out.println(e.nombreInvite(4));
//       System.out.println(e.nombreInvite(4));
//        
//     Activite t = new Activite() ;
//      t.ajouter(new Act(8,"hello", "bye"));
//     t.modifier(new Act(8,"hel","by"));
//      t.supprimer(new Act("hel")); */
     // t.afficher().forEach(System.out::println);//
        
   /* GesInv inv = new GesInv();
     Invitation invitation1= new Invitation(9,10);
     inv.ajouter(invitation1);
     inv.supprimer(invitation1); */
}

}
