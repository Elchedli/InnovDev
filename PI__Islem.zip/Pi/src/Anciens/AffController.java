package Anciens;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import Services.Activite;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Act;

/**
 * FXML Controller class
 *
 * @author Islem
 */
public class AffController implements Initializable {

    @FXML
    private Button but;
    @FXML
    private TableView<Act> tabid;
    @FXML
    private TableColumn<Act, Integer> colid;
    @FXML
    private TableColumn<Act, String> colnom;
    @FXML
    private TableColumn<Act, String> coltype;
private ObservableList<Act> activs = FXCollections.observableArrayList();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void button(ActionEvent event) {
      colid.setCellValueFactory(new PropertyValueFactory<Act,Integer>("id_act"));
     colnom.setCellValueFactory(new PropertyValueFactory<Act,String>("nom_act"));        
     coltype.setCellValueFactory(new PropertyValueFactory<Act,String>("type_act"));
         try {
             Activite t = new Activite();
      
      for(Act acct : t.afficher()){
      activs.add(new Act( acct.getId_act(), acct.getNom_act(), acct.getType_act()));     }
        
       tabid.setItems(activs); 
     
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
    }
}
    }
    
