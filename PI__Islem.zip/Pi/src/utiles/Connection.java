/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utiles;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Islem
 */
public class Connection {
    private static Connection instance;
    private java.sql.Connection cnx;

    private final String URL = "jdbc:mysql://localhost:3306/spirity";
    private final String LOGIN = "root";
    private final String PASSWORD = "";

    private Connection() {
        try {
            cnx = DriverManager.getConnection(URL, LOGIN, PASSWORD);
            System.out.println("Connecting !");
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    public static Connection getInstance() {
        if (instance == null) {
            instance = new Connection();
        }
        return instance;
    }

    public java.sql.Connection getCnx() {
        return cnx;
    }
}

   
