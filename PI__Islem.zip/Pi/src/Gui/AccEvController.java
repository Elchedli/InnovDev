/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;


/**
 * FXML Controller class
 *
 * @author Islem
 */
public class AccEvController implements Initializable {

    @FXML
    private Button Add;
    @FXML
    private Button edit;
    @FXML
    private Button acivités;
    @FXML
    private Button invitations;
        @FXML
    private Button option;
    @FXML
    private ImageView imgv1;
    @FXML
    private ImageView imgv4;
    @FXML
    private ImageView imgv5;
    @FXML
    private ImageView imgv2;
    @FXML
    private ImageView imgv3;
    @FXML
    private AnchorPane holderPane;   
    @FXML
    private Button Statistic;

  
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Add_event(ActionEvent event) throws IOException {
         FXMLLoader loader =new FXMLLoader (getClass().getResource("../Gui/AjouterEvent.fxml"));
        Parent root= loader.load();
      Add.getScene().setRoot(root);
    }

    @FXML
    private void edit_event(ActionEvent event) throws IOException {
           FXMLLoader loader =new FXMLLoader (getClass().getResource("../Gui/EditEvent.fxml"));
        Parent root= loader.load();
      Add.getScene().setRoot(root);
    }

    @FXML
    private void activités(ActionEvent event) throws IOException {
           FXMLLoader loader =new FXMLLoader (getClass().getResource("../Gui/Activités.fxml"));
        Parent root= loader.load();
      Add.getScene().setRoot(root);
    }

    @FXML
    private void invitations(ActionEvent event) throws IOException {
        FXMLLoader loader =new FXMLLoader (getClass().getResource("../Gui/Invitation.fxml"));
        Parent root= loader.load();
      Add.getScene().setRoot(root);
    }

    @FXML
    void options(ActionEvent event) throws IOException {
   FXMLLoader loader =new FXMLLoader (getClass().getResource("../Gui/EventMetier.fxml"));
        Parent root= loader.load();
      Add.getScene().setRoot(root);
    }
     @FXML
    void Statistic(ActionEvent event) throws IOException {
          FXMLLoader loader =new FXMLLoader (getClass().getResource("../Gui/Statistic.fxml"));
        Parent root= loader.load();
      Add.getScene().setRoot(root);

    }
           @FXML
    private void back(ActionEvent event) throws IOException {
    
    
}
}
